package com.hotel.group.hotelserver;

public class RoomUnavailableException extends Exception {

    public RoomUnavailableException() {
        super();
    }
}
